#!/bin/sh

cd /home/user/MyDocs/wl1251-maemo/binary/compat-wireless/
sudo sh unload.sh
sleep 1
echo "Stock wl1251 module loaded"
sudo sh unload.sh