#!/bin/sh

cd /home/user/MyDocs/wl1251-maemo/binary/compat-wireless/
sudo sh load.sh
sleep 1
echo "Custom wl1251 module loaded (with injection) :)"
sudo sh load.sh