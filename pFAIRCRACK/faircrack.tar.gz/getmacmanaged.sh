#!/bin/sh

sudo ifconfig  wlan0 | grep wlan0 | awk -F"addr" 'BEGIN {OFS = ":"};{gsub(" ","")}; {print $2}' > mymac.txt