#!/bin/sh
#sudo gainroot

if [ -f temp-01.csv ]; then
	sudo rm temp-*
fi
sudo airodump-ng -w temp wlan0 &
my_PID=$!
sleep $scanduration
sudo kill -15 $my_PID

