#!/usr/bin/python2.5
import sys
import os
import subprocess
from PyQt4 import QtGui,QtCore
from FAS import *

class MyForm(QtGui.QMainWindow):
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)
		self.ui = Ui_MainWindow()
		self.ui.setupUi(self)
		self.setWindowTitle('fAircrack V0.3')
		self.doCheckInterface()
		self.doShowMac()
		self.doRefreshCaps()
		self.scanned = 0

		# Monitor
		QtCore.QObject.connect(self.ui.enableMonitor, QtCore.SIGNAL('clicked()'), self.doEnableMonitor)
		QtCore.QObject.connect(self.ui.disableMonitor, QtCore.SIGNAL('clicked()'), self.doDisableMonitor)
		QtCore.QObject.connect(self.ui.enableInjection, QtCore.SIGNAL('clicked()'), self.doEnableInjection)
		QtCore.QObject.connect(self.ui.disableInjection, QtCore.SIGNAL('clicked()'), self.doDisableInjection)
		QtCore.QObject.connect(self.ui.macButton, QtCore.SIGNAL('clicked()'), self.doSetMac)
		QtCore.QObject.connect(self.ui.randomButton, QtCore.SIGNAL('clicked()'), self.doSetRandomMac)

		# Access Point
		QtCore.QObject.connect(self.ui.scanButton, QtCore.SIGNAL('clicked()'), self.doScanNetworks)
		QtCore.QObject.connect(self.ui.captureButton, QtCore.SIGNAL('clicked()'), self.doCapture)
		QtCore.QObject.connect(self.ui.wepRadio, QtCore.SIGNAL('clicked()'), self.doDisplayNetworks)
		QtCore.QObject.connect(self.ui.wpaRadio, QtCore.SIGNAL('clicked()'), self.doDisplayNetworks)
		QtCore.QObject.connect(self.ui.scanList, QtCore.SIGNAL('itemSelectionChanged()'), self.doEnableCapture)

		# Injection
		QtCore.QObject.connect(self.ui.authenticateButton, QtCore.SIGNAL('clicked()'), self.doAuthenticate)
		QtCore.QObject.connect(self.ui.injectionButton, QtCore.SIGNAL('clicked()'), self.doInjection)

		# Decryption
		QtCore.QObject.connect(self.ui.decryptWepButton, QtCore.SIGNAL('clicked()'), self.doDecryptWEP)
		QtCore.QObject.connect(self.ui.decryptWpaButton, QtCore.SIGNAL('clicked()'), self.doDecryptWPA)
		QtCore.QObject.connect(self.ui.clearWepButton, QtCore.SIGNAL('clicked()'), self.doClearWEPCaps)
		QtCore.QObject.connect(self.ui.clearWpaButton, QtCore.SIGNAL('clicked()'), self.doClearWPACaps)
		QtCore.QObject.connect(self.ui.keyButton, QtCore.SIGNAL('clicked()'), self.doCheckKey)
		QtCore.QObject.connect(self.ui.refreshWepButton, QtCore.SIGNAL('clicked()'), self.doRefreshCaps)
		QtCore.QObject.connect(self.ui.refreshWpaButton, QtCore.SIGNAL('clicked()'), self.doRefreshCaps)
		QtCore.QObject.connect(self.ui.refreshKeysButton, QtCore.SIGNAL('clicked()'), self.doRefreshCaps)
		QtCore.QObject.connect(self.ui.wepList, QtCore.SIGNAL('itemSelectionChanged()'), self.doEnableWEPDecryption)
		QtCore.QObject.connect(self.ui.wpaList, QtCore.SIGNAL('itemSelectionChanged()'), self.doEnableWPADecryption)
		QtCore.QObject.connect(self.ui.dictionaryList, QtCore.SIGNAL('itemSelectionChanged()'), self.doEnableWPADecryption)

	def doCheckInterface(self):
		os.system('sh getinterfacestate.sh')
		interfaceState = open('interface.txt', "r")
		state = interfaceState.read()
		if state.strip() == "Ma":
			self.ui.disableMonitor.setEnabled(False)
			self.ui.enableMonitor.setEnabled(True)
		elif state.strip() == "Mo":
			self.ui.disableMonitor.setEnabled(True)
			self.ui.enableMonitor.setEnabled(False)
		interfaceState.close()

	def doEnableMonitor(self):
		os.system('sudo ifconfig wlan0 down')
		os.system('sudo iwconfig wlan0 mode Monitor')
		os.system('sudo ifconfig wlan0 up')
		self.doCheckInterface()
		self.doShowMac()

	def doDisableMonitor(self):
		os.system('sudo ifconfig wlan0 down')
		os.system('sudo iwconfig wlan0 mode Managed')
		os.system('sudo ifconfig wlan0 up')
		self.doCheckInterface()
		self.doShowMac()

	def doEnableInjection(self):
		os.system('sh load.sh')
		self.doCheckInterface()
		self.doShowMac()

	def doDisableInjection(self):
		os.system('sh unload.sh')
		self.doCheckInterface()
		self.doShowMac()

	def doShowMac(self):
		if self.ui.enableMonitor.isEnabled() == True:
			os.system('sh getmacmanaged.sh')
		else:
			os.system('sh getmacmonitor.sh')
		currentmac = open('mymac.txt', "r")
		macList = currentmac.read()
		self.mymac = macList[0:17]
		self.ui.macEdit.setText(self.mymac)
		currentmac.close()

	def doSetRandomMac(self):
		os.system('sudo ifconfig wlan0 down')
		os.system('sudo macchanger -r wlan0')
		os.system('sudo ifconfig wlan0 up')
		self.doShowMac()

	def doSetMac(self):
		newmac = str(self.ui.macEdit.text())
		os.environ["newmac"] = newmac.strip()
		os.system('sudo ifconfig wlan0 down')
		os.system('sudo macchanger -m $newmac wlan0')
		os.system('sudo ifconfig wlan0 up')
		self.doShowMac()

	def doScanNetworks(self):
		if self.ui.disableMonitor.isEnabled() == False:
			return
		duration = str(self.ui.durationSpin.value())
		os.environ["scanduration"] = duration
		os.system('sh scan.sh')
		self.scanned = 1
		self.doDisplayNetworks()

	def doDisplayNetworks(self):
		if self.scanned == 0:
			return
		self.ui.scanList.clear()
		if self.ui.wepRadio.isChecked() == True:
			os.environ["WEPorWPA"] = "WEP"
		else:
			os.environ["WEPorWPA"] = "WPA"
		os.system('sh readAP.sh')
		scan = open("scanresults.txt", "r")
		values = scan.readlines()
		qlist = QtCore.QStringList(map(QtCore.QString, values))
		self.ui.scanList.addItems(qlist)

	def doEnableCapture(self):
		if self.ui.scanList.currentRow() == -1:
			return
		self.ui.captureButton.setEnabled(True)
		self.essid = self.ui.scanList.currentItem().text()
		os.environ["essid"] = str(self.essid)
		os.system('sh getinfo.sh')
		currentAP = open('currentAP.txt', "r")
		infoList = currentAP.readlines()
		currentAP.close()
		self.essid = infoList[0]
		self.bssid = infoList[1]
		self.channel = infoList[2]
		self.encryption = infoList[3]
		self.ui.textBrowser.clear()
		self.ui.textBrowser.append(self.essid.strip())
		self.ui.textBrowser.append(self.bssid.strip())
		self.ui.textBrowser.append(self.channel.strip())
		self.ui.textBrowser.append(self.encryption.strip())

	def doCapture(self):
		if self.ui.scanList.currentRow() == -1:
			self.ui.captureButton.setEnabled(False)
			self.ui.authenticateButton.setEnabled(False)
			self.ui.injectionButton.setEnabled(False)
			return
		self.essid = self.ui.scanList.currentItem().text()
		os.environ["essid"] = str(self.essid)
		os.system('sh getinfo.sh')
		currentAP = open('currentAP.txt', "r")
		infoList = currentAP.readlines()
		currentAP.close()
		self.essid = infoList[0]
		self.bssid = infoList[1]
		self.channel = infoList[2]
		if self.ui.wepRadio.isChecked() == True:
			self.encryption = "WEP"
			self.ui.authenticateButton.setEnabled(True)
			self.ui.injectionButton.setEnabled(True)
		else:
			self.encryption = "WPA"
		#self.encryption = infoList[3]
		os.environ["essid"] = str(self.essid)
		os.environ["bssid"] = str(self.bssid)
		os.environ["channel"] = str(self.channel)
		os.environ["encryption"] = str(self.encryption)
		os.system('osso-xterm -e "sudo airodump-ng --channel $channel --bssid $bssid --write /home/user/MyDocs/FAS/cap/$WEPorWPA/$essid wlan0" &')

	def doAuthenticate(self):
		if self.ui.enableMonitor.isEnabled() == True:
			os.system('sh getmacmanaged.sh')
		else:
			os.system('sh getmacmonitor.sh')
		currentmac = open('mymac.txt', "r")
		macList = currentmac.read()
		currentmac.close()
		self.mymac = macList[0:17]
		os.environ["mymac"] = str(self.mymac)
		os.system('osso-xterm -e "sudo aireplay-ng -1 5 -q 10 -e $essid -a $bssid -h $mymac wlan0" &')

	def doInjection(self):
		if self.ui.enableMonitor.isEnabled() == True:
			os.system('sh getmacmanaged.sh')
		else:
			os.system('sh getmacmonitor.sh')
		currentmac = open('mymac.txt', "r")
		macList = currentmac.read()
		currentmac.close()
		self.mymac = macList[0:17]
		os.environ["mymac"] = str(self.mymac)
		os.system('osso-xterm -e "sudo aireplay-ng -3 -b $bssid -h $mymac wlan0" &')

	def doEnableWEPDecryption(self):
		self.ui.decryptWepButton.setEnabled(True)

	def doEnableWPADecryption(self):
		self.ui.decryptWpaButton.setEnabled(True)

	def doRefreshCaps(self):
		os.system('ls -t /home/user/MyDocs/FAS/cap/WEP/*.cap | xargs -n1 basename > wepcaplist.txt')
		self.ui.wepList.clear()
		caps = open("wepcaplist.txt", "r")
		values = caps.readlines()
		qlist = QtCore.QStringList(map(QtCore.QString, values))
		self.ui.wepList.addItems(qlist)
		os.system('ls -t /home/user/MyDocs/FAS/cap/WPA/*.cap | xargs -n1 basename > wpacaplist.txt')
		self.ui.wpaList.clear()
		caps = open("wpacaplist.txt", "r")
		values = caps.readlines()
		qlist = QtCore.QStringList(map(QtCore.QString, values))
		self.ui.wpaList.addItems(qlist)
		os.system('ls /home/user/MyDocs/FAS/diction/ | xargs -n1 basename > dictionlist.txt')
		self.ui.dictionaryList.clear()
		diction = open("dictionlist.txt", "r")
		dvalues = diction.readlines()
		dqlist = QtCore.QStringList(map(QtCore.QString, dvalues))
		self.ui.dictionaryList.addItems(dqlist)
		os.system('ls -t /home/user/MyDocs/FAS/keys/ | xargs -n1 basename > keylist.txt')
		self.ui.keyList.clear()
		keys = open("keylist.txt", "r")
		kvalues = keys.readlines()
		kqlist = QtCore.QStringList(map(QtCore.QString, kvalues))
		self.ui.keyList.addItems(kqlist)

	def doClearWEPCaps(self):
		os.system('sudo rm cap/WEP/*.*')
		self.doRefreshCaps()

	def doClearWPACaps(self):
		os.system('sudo rm cap/WPA/*.*')
		self.doRefreshCaps()

	def doDecryptWEP(self):
		if self.ui.wepList.currentRow() == -1:
			self.ui.decryptWepButton.setEnabled(False)
			return
		capfile = str(self.ui.wepList.currentItem().text())
		os.environ["cap"] = capfile.strip()
		os.system('osso-xterm -e "sudo aircrack-ng -l /home/user/MyDocs/FAS/keys/$cap.txt /home/user/MyDocs/FAS/cap/WEP/$cap" &')

	def doDecryptWPA(self):
		if self.ui.wpaList.currentRow() == -1:
			self.ui.decryptWpaButton.setEnabled(False)
			return
		capfile = str(self.ui.wpaList.currentItem().text())
		os.environ["cap"] = capfile.strip()
		if self.ui.wordRadio.isChecked() == True:
			if self.ui.dictionaryList.currentRow() == -1:
				self.ui.decryptWpaButton.setEnabled(False)
				return
			else:
				wordlist = self.ui.dictionaryList.currentItem().text()
				os.environ["wordlist"] = str(wordlist)
				os.system('osso-xterm -e "sudo aircrack-ng -a 2 -w /home/user/MyDocs/FAS/diction/$wordlist -l /home/user/MyDocs/FAS/keys/$cap.txt /home/user/MyDocs/FAS/cap/WPA/$cap" &')
		else:
			if self.ui.lettersCheck.isChecked() == False and self.ui.digitsCheck.isChecked() == False:
				return
			else:
				currentcap = capfile.strip()
				essid = currentcap[:-7]
				os.environ["targetessid"] = essid.strip()
				capfile = str(self.ui.wpaList.currentItem().text())
				os.environ["johncap"] = capfile.strip()
				if self.ui.lettersCheck.isChecked() == True and self.ui.digitsCheck.isChecked() == True:
					os.environ["incmode"] = "Alnum"
				elif self.ui.lettersCheck.isChecked() == True and self.ui.digitsCheck.isChecked() == False:
					os.environ["incmode"] = "Alpha"
				elif self.ui.lettersCheck.isChecked() == False and self.ui.digitsCheck.isChecked() == True:
					os.environ["incmode"] = "Digits"
				os.system('echo johncap=$johncap > johnconf.sh')
				os.system('echo targetessid=$targetessid >> johnconf.sh')
				os.system('echo incmode=$incmode >> johnconf.sh')
				os.system('echo export johncap=$johncap >> johnconf.sh')
				os.system('echo export targetessid=$targetessid >> johnconf.sh')
				os.system('echo export incmode=$incmode >> johnconf.sh')
				os.system('osso-xterm -e "sh /home/user/MyDocs/FAS/john.sh" &')

	def doCheckKey(self):
		if self.ui.keyList.currentRow() == -1:
			self.ui.keyBrowser.setText("None selected")
			return
		keyname = str(self.ui.keyList.currentItem().text())
		keyfile = keyname.strip()
		try:
			actualkey = open("keys/%s" % (keyfile))
			key = actualkey.readline()
			self.ui.keyBrowser.setText(key)
		except IOError:
			self.ui.keyBrowser.setText("No longer exists")

if __name__ == "__main__":
        app = QtGui.QApplication(sys.argv)
        myapp = MyForm()
        myapp.show()
        sys.exit(app.exec_())

