#!/bin/sh

sudo ifconfig | grep wlan0 | awk -F"addr" 'BEGIN {OFS = ":"};{gsub(" ","")}; {print $2}' | awk -F"-" 'BEGIN {OFS = ":"};{gsub(" ","")}; {print $1,$2,$3,$4,$5,$6}' > mymac.txt