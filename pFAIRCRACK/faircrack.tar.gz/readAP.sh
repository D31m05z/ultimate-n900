#!/bin/sh

cat temp-01.csv | grep -e $WEPorWPA | awk -F"," 'BEGIN {OFS = ","};{gsub(" ","")}; {print $14}' > scanresults.txt
