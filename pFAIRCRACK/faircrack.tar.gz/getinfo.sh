#!/bin/sh

cat temp-01.csv | grep -e $essid | grep -e WPA -e WEP | awk -F"," 'BEGIN {OFS = "\n"};{gsub(" ","")}; {print $14,$1,$4,$6}' > currentAP.txt
