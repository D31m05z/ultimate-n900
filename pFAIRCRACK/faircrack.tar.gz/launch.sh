cd /home/user/MyDocs/FAS/
python Main.py