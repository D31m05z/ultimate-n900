#!/bin/bash
killall john
sudo killall aircrack-ng
cd /home/user/MyDocs/FAS/
. ./johnconf.sh
john --config=/home/user/MyDocs/FAS/john.conf --incremental:$incmode --stdout | sudo aircrack-ng -e $targetessid -w - -l /home/user/MyDocs/FAS/keys/$johncap.txt /home/user/MyDocs/FAS/cap/WPA/$johncap
