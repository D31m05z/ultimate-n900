johncap=SKY05593-03.cap
targetessid=SKY05593
incmode=Digits
export johncap=SKY05593-03.cap
export targetessid=SKY05593
export incmode=Digits
