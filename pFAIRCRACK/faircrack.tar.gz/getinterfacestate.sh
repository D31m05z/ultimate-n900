#!/bin/sh

sudo iwconfig wlan0 | grep -e Mode | awk -F":" 'BEGIN {gsub(" ","")}; {print $2}' | awk -F"n" 'BEGIN {gsub(" ","")}; {print $1}' > interface.txt